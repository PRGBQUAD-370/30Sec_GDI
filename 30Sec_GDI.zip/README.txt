If you do not have s X86 Runtime Package installed do not remove the vcruntime140.dll other wise this program won't Run

Download the dll on the github page and put it in the same folder if your getting the vcruntime140.dll error